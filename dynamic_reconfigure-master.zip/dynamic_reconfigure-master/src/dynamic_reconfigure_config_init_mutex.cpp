#include <dynamic_reconfigure/config_init_mutex.h>

boost::mutex dynamic_reconfigure::__init_mutex__;
