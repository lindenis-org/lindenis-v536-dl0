To avoid duplicating information we link to the Notice.md file in optee_os which
states the contributor agreement rules etc, i.e, optee_client follows what is
written in the Notice.md on the URL below
https://github.com/OP-TEE/optee_os/blob/master/Notice.md
