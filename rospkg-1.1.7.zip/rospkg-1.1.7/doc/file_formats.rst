File formats
============

.. toctree::
   :maxdepth: 2

   manifest_xml
   stack_xml
   distro_format
