#include <stdio.h>
#include <stdlib.h>

#include "nsutils.h"

const char *get_ns_name(int id)
{
	return NULL;
}

int main(int argc, char *argv[])
{
	printf("Hello, World!\n");
	return EXIT_SUCCESS;
}
