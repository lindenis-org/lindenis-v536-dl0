#!/bin/sh

pod2man --section 8 vmtouch.pod > vmtouch.8
