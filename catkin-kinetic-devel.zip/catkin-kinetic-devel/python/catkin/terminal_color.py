# for backward compatibility
from catkin_pkg.terminal_color import *  # noqa
