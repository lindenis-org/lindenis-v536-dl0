This folder contains utiliy scripts and files used during the
development of catkin in fuerte. They seem to be outdated and
unmaintained. To be deleted once we are sure we don't care about them
anymore.
