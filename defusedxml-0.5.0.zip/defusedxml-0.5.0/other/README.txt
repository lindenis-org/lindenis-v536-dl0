This directory contains test and demo scripts for other frameworks and
languages. I used them to examine the characteristics of XML parsers.

