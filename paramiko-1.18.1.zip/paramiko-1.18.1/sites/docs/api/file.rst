Buffered files
==============

.. automodule:: paramiko.file
