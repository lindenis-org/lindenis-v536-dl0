# -*- coding: utf-8 -*-
"""
    sphinx.writers
    ~~~~~~~~~~~~~~

    Custom docutils writers.

    :copyright: Copyright 2007-2016 by the Sphinx team, see AUTHORS.
    :license: BSD, see LICENSE for details.
"""
