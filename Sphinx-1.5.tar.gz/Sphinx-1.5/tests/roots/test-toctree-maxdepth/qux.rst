test-toctree-max-depth
======================

.. toctree::
   :numbered:
   :maxdepth: 4

   foo
   bar
