test-toctree-max-depth
======================

.. toctree::
   :numbered:
   :maxdepth: 2

   foo
   bar
