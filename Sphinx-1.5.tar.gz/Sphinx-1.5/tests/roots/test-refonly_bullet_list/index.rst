test-refonly_bullet_list
========================

List A:

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

List B:

* Hello
* Sphinx
* World
