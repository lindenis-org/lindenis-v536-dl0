# -*- coding: utf-8 -*-

master_doc = 'index'
html_compact_lists = False

latex_documents = [
    (master_doc, 'test.tex', 'The basic Sphinx documentation for testing', 'Sphinx', 'report')
]
