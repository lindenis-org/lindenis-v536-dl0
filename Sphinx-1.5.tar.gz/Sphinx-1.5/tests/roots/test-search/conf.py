master_doc = 'index'
exclude_patterns = ['_build']
html_search_language = 'en'
