test-maxlistdepth
=================


1. 1

   1. 2

      1. 3

         1. 4

            1. 5

               1. 6

                  1. 7

                     1. 8

                        1. 9

                             10a

                           - 10b

                             .. code-block:: python

                                 def foo():


- 1

   - 2

      - 3

         - 4

            - 5

               - 6

                  - 7

                     - 8

                       1. 9

                             10a

                          1. 10b

                             .. code-block:: python

                                  def foo():

