.. admonition:: Notice

   This generates nodes.title node before first section title.

test-latex-title
================

.. toctree::
   :numbered:

   foo
   bar
