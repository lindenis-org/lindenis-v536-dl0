# -*- coding: utf-8 -*-

master_doc = 'index'

# set empty string to the third column to use the first section title to document title
latex_documents = [
    (master_doc, 'test.tex', '', 'Sphinx', 'report')
]
