Test math extensions :math:`E = m c^2`
======================================

This is inline math: :math:`a^2 + b^2 = c^2`.

.. math:: a^2 + b^2 = c^2

.. math::

   a + 1 < b

.. math::
   :label: foo

   e^{i\pi} = 1

.. math::
   :label:

   e^{ix} = \cos x + i\sin x

.. math::

   n \in \mathbb N

.. math::
   :nowrap:

   a + 1 < b

Referencing equation :eq:`foo`.
