test-image-glob/subdir
======================

.. image:: rimg.png

.. image:: svgimg.*

.. figure:: svgimg.*

   The caption of svgimg
