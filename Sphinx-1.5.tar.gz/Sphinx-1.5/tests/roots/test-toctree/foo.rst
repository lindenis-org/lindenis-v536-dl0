foo
===

.. toctree::

   quux

foo.1
-----

foo.1-1
^^^^^^^

foo.2
-----
