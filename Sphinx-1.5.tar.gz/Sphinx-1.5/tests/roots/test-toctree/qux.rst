qux.rst has no section title
