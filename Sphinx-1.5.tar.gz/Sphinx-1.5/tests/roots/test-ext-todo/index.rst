test for sphinx.ext.todo
========================

.. toctree::

   foo
   bar

.. todolist::
