#ifndef _MDOLPHIN_URL_H
#define _MDOLPHIN_URL_H


const char *sg_urlData[]=
{
    "www.sina.com.cn",
    "http://news.sina.com.cn/",
    "http://sports.sina.com.cn/",
    "http://news.sina.com.cn/society/",
    "www.sohu.com.cn",
    "www.ifeng.com",
    "http://tech.sina.com.cn/",
    "www.baidu.com",
    "http://news.baidu.com/",
    "http://news.ifeng.com/",
    "http://news.ifeng.com/sports/",
    "www.google.com",
    "http://maps.google.com/maps?hl=en&tab=wl",
    "http://news.sohu.com/",
    "http://www.163.com/",
    "http://www.xinhuanet.com/",
    "http://finance.sina.com.cn/money/globalindex/index.shtml",
    "http://bbs.pcbeta.com/index.php",
    "http://forum.xitek.com/showthread.php?threadid=620403",
    "http://money.163.com/",
    "http://www.gov.cn/",
    "http://www.minigui.com",
    "http://www.minigui.org/cgi-bin/lb5000/leoboard.cgi",

};

#endif


