Coding standards :
=================

- Standard naming for header file and cpp file : hpp and cpp
- KDL namespace and references.

Directories:
============

utilities: utility classes for KDL, should not be included separately
	   by a user

experimental: preliminary code snippets.

bindings: code for binding KDL with other libraries or coding-languages