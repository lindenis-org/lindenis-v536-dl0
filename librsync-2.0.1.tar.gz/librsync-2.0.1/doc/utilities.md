# Utility functions {#api_utility}

Some additional functions are used internally and also exposed in the
API:

- encoding/decoding binary data: rs_base64(), rs_unbase64(),
  rs_hexify().
  
- MD4 message digests: rs_mdfour(), rs_mdfour_begin(),
  rs_mdfour_update(), rs_mdfour_result().
