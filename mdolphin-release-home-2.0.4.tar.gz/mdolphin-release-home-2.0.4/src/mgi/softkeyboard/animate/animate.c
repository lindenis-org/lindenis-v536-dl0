#include <stdio.h>
#include <stdlib.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <minigui/common.h>
#include <minigui/minigui.h>
#include <minigui/gdi.h>
#include <minigui/window.h>

#ifdef KBD_ANIMATE

//#define FUN_DEBUG
//#define VAL_DEBUG
//#define INFO_DEBUG
#include "my_debug.h"

#include "animate.h"


#endif
