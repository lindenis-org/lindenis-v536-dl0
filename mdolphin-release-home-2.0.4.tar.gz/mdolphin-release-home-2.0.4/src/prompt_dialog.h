#ifndef __PROMPOT_H__
#define __PROMPOT_H__
int prompt_box(HWND parent, const char *info, const char *definp, char *buf, int buflen);
#endif
