#ifndef __TOOLTIPWIN_H__
#define __TOOLTIPWIN_H__
void my_tooltip(HWND hWnd, int x, int y, const char *text, BOOL bShow);
#endif
