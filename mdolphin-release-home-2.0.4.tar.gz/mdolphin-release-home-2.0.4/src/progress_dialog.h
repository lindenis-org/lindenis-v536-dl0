#ifndef _PROGRESS_DIALOG_H
#define _PROGRESS_DIALOG_H
HWND create_save_window(const char * fileName, int id);
void destroy_save_window(HWND hwnd);
#endif
