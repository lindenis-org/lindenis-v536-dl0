#ifndef SCROLLPANEL_H_
#define SCROLLPANEL_H_

void navigate_compass_window(bool isshow);
void navigate_compass_showwindow();

#endif
